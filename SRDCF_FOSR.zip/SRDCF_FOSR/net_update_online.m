function [hf_out,wd] = net_update(xxf,xyf,hf,params,wd,w0)
maxit = params.it;  % 7
thf = hf;
it = 1;
lr = params.lr;
lr_w = params.lr_w;
threshold = params.th;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
while it<maxit
    %% optimize f
    gradf =  bsxfun(@times, xxf, thf)-xyf;
    grad = real(ifft2(gradf));
    thf_time = ifft2(thf);
    thf_time = bsxfun(@times,wd,thf_time)-lr.*grad ;
    thf = fft2(thf_time);
    %% optimize w
    grad_w = sum(real(bsxfun(@times, thf_time, thf_time)),3);
    grad_w = grad_w + lr_w;
    w = (lr_w .* w0) ./ grad_w;
    wd = w .* w;
    wd(wd>threshold) = threshold;
    wd = wd .* lr ;
    wd = 1 - wd;
    %%
    it = it+1;
end
%% close form solution
hf_out = thf;