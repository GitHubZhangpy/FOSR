function [hf_out,recordF,hf_pre] = net_update_offline(xxf,xyf,hf,wd,params)
maxit = 5;  % 4
hf_pre = ifft2(hf);
thf = hf;
it = 1;
lr = params.lr;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
recordF = {};
while it<maxit
    %% optimize f
    gradf =  bsxfun(@times, xxf, thf)-xyf;
    grad = real(ifft2(gradf));
    thf_time = ifft2(thf);
    thf_time = bsxfun(@times,wd,thf_time)-lr.*grad ;
    thf = fft2(thf_time);
    recordF{it} =thf_time;  
    it = it+1;
end

hf_out = thf;