path = '/media/zpy/Seagate Backup Plus Drive/VOT16_titan/trackers/SRDCF_FOSR';

tracker_label = 'SRDCF_FOSR';
tracker_command = generate_matlab_command('benchmark_tracker_wrapper(''SRDCF_FOSR'', ''run_SRDCF_FOSR_vot'', true)', {[path '/benchmark_wrapper']});
tracker_interpreter = 'matlab';



