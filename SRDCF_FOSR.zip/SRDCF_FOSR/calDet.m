function [detF_temp,detW] = calDet(xxf,wd,filter,iter,hf_pre,lr,w)

if iter-1 ~= size(filter,2)
    error('The size of filter is not right!');
end
detW = cell(iter-1,1);
detF_temp = zeros(size(xxf));
for c = 1:size(xxf,3)
    detF_temp(:,:,c) = wd - lr * ifftshift(ifft2(ifft2(xxf(:,:,c))));
end
for i = 1: iter-1
    if i == 1
        detW{i} = (-2 * lr .* bsxfun(@times,w,hf_pre)); %%det_f1_w

    else
        detW{i} = (-2 * lr .* bsxfun(@times,w,filter{i-1})); 
    end
end